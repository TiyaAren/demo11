package com.example.demo.entity;

public class Hobby {
}
