package com.example.demo.entity;

public class Account {
}
